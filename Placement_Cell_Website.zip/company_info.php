<?php
session_start();
include 'db.php'; // Include the database connection

// Check if user is logged in as admin
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php"); // Redirect to login page if not logged in or not an admin
    exit();
}

// Fetch company data from the database
$sql = "SELECT * FROM companies";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Companies and Students</title>
    <style>
        body {
            background-color: #f8f9fa; /* Light background */
        }
        .table {
            border-radius: 0.5rem;
            overflow: hidden; /* Rounded corners */
        }
        th {
            background-color: #ff7b00; /* Header color */
            color: rgb(247, 178, 31); /* Header text color */
        }
        .add-button {
      font-size: 20px;
      padding: 10px 15px;
      background-color: black;
      color: white;
      border: none;
      border-radius: 50%;
      cursor: pointer;
      position: fixed;
      bottom: 20px;
      right: 20px;
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2);
    }
    .add-button:hover {
      background-color: gray;
    }
    </style>
    <link rel="stylesheet" href="styles.css">
</head>
<body>

  <!-- Navigation Bar -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="index.php">Placement Portal</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="company_info.php">Company</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="training.php">Training</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="placed_students.php">Placed Students</a>
                    </li>
                </ul>
            </div>
            <div class="d-flex">
                <span class="navbar-text me-3">Welcome, <?= htmlspecialchars($_SESSION['username']); ?></span>
                <a href="main.php" class="btn btn-danger btn-sm">Logout</a>
            </div>
        </div>
    </nav>
    <div class="container mt-5">
        <h2 class="text-center mb-4">Companies</h2>
        <table class="table table-striped table-hover">
            <thead>
                <tr>
                    <th scope="col">Sr.No.</th>
                    <th scope="col">Company Name</th>
                    <th scope="col">Founder</th>
                    <th scope="col">CEO</th>
                    <th scope="col">Chairman</th>
                    <th scope="col">Founded Date</th>
                    <th scope="col">Headquarters</th>
                    <th scope="col">Official Link</th>
                </tr>
            </thead>
            <tbody>
                <?php
                // Check if there are any companies in the database
                if ($result->num_rows > 0) {
                    // Fetch and display each company record
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>
                                <td>" . $row['id'] . "</td>
                                <td>" . $row['name'] . "</td>
                                <td>" . $row['founder'] . "</td>
                                <td>" . $row['ceo'] . "</td>
                                <td>" . $row['chairman'] . "</td>
                                <td>" . date('d-m-Y', strtotime($row['founded_date'])) . "</td>
                                <td>" . $row['headquarters'] . "</td>
                                <td><a href='" . $row['official_link'] . "' target='_blank'>Official Site</a></td>
                              </tr>";
                    }
                } else {
                    // Display a message if no companies are found
                    echo "<tr><td colspan='8' class='text-center'>No company details found.</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>


    <a href="add_company.php" class="add-button" title="Add New Company">+</a>


</body>
</html>
