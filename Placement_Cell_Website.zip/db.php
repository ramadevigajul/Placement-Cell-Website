<?php
// Database credentials
$host = 'localhost';        // Replace with your database host (usually 'localhost')
$db = 'student_placements'; // Replace with your database name
$user = 'root';             // Replace with your database username
$password = 'root';             // Replace with your database password

// Create a connection
$conn = new mysqli($host, $user, $password, $db);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Optional: Uncomment the line below to verify the connection during testing
// echo "Connected successfully";
?>
