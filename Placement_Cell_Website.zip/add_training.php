<?php
// Start the session
session_start();

// Check if the user is an admin
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'admin') {
    // Redirect to login page if the user is not logged in as admin
    header('Location: login.php');
    exit();
}

// Include the database connection from db.php
include('db.php');

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get and sanitize form inputs
    $org_name = mysqli_real_escape_string($conn, $_POST['org_name']);
    $training_type = mysqli_real_escape_string($conn, $_POST['training_type']);
    $num_days = mysqli_real_escape_string($conn, $_POST['num_days']);
    $trainer_details = mysqli_real_escape_string($conn, $_POST['trainer_details']);
    $syllabus = mysqli_real_escape_string($conn, $_POST['syllabus']);
    $start_date = mysqli_real_escape_string($conn, $_POST['start_date']);

    // SQL query to insert the training details into the database
    $sql = "INSERT INTO training_details (org_name, training_type, num_days, trainer_details, syllabus, start_date)
            VALUES ('$org_name', '$training_type', '$num_days', '$trainer_details', '$syllabus', '$start_date')";

    // Check if the query was successful
    if (mysqli_query($conn, $sql)) {
        // Redirect back to the training details page
        echo "<script>alert('Training details added successfully!'); window.location.href = 'training.php';</script>";
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }

    // Close the database connection
    mysqli_close($conn);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Add Training</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
  <link rel="stylesheet" href="styles.css">
</head>
<body>
  <!-- Navigation Bar -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container-fluid">
        <a class="navbar-brand" href="index.php">Placement Portal</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" href="company.php">Company</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="training.php">Training</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="placed_students.php">Placed Students</a>
                </li>
            </ul>
        </div>
        <div class="d-flex">
            <span class="navbar-text me-3">Welcome, <?= htmlspecialchars($_SESSION['username']); ?></span>
            <a href="main.php" class="btn btn-danger btn-sm">Logout</a>
        </div>
    </div>
  </nav>

  <!-- Add Training Form -->
  <div class="container mt-5" style="width: 80%; max-width:800px; margin: 0 auto; padding: 20px;">
    <h2>Add New Training Details</h2>

    <form method="POST" action="">
      <div class="mb-3">
        <label for="org_name" class="form-label">Organization Name</label>
        <input type="text" class="form-control" id="org_name" name="org_name" required>
      </div>

      <div class="mb-3">
        <label for="training_type" class="form-label">Training Type</label>
        <select class="form-select" id="training_type" name="training_type" required>
          <option value="">Select Training Type</option>
          <option value="technical">Technical</option>
          <option value="soft skills">Soft Skills</option>
          <option value="workshop">Workshop</option>
        </select>
      </div>

      <div class="mb-3">
        <label for="num_days" class="form-label">Number of Days</label>
        <input type="number" class="form-control" id="num_days" name="num_days" required>
      </div>

      <div class="mb-3">
        <label for="trainer_details" class="form-label">Trainer Details</label>
        <textarea class="form-control" id="trainer_details" name="trainer_details" rows="3" required></textarea>
      </div>

      <div class="mb-3">
        <label for="syllabus" class="form-label">Syllabus</label>
        <textarea class="form-control"id="syllabus" name="syllabus" rows="3" required></textarea>
      </div>

      <div class="mb-3">
        <label for="start_date" class="form-label">Start Date</label>
        <input type="date" class="form-control" id="start_date" name="start_date" required>
      </div>

      <button type="submit" class="btn btn-primary" style="background-color:black;">Add Training</button>
    </form>
  </div>
</body>
</html>
