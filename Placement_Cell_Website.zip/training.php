<?php
// Start the session
session_start();

// Check if the user is an admin
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'admin') {
    // Redirect to login page if the user is not logged in as admin
    header('Location: login.php');
    exit();
}

// Include the database connection from db.php
include('db.php');

// Fetch all training details from the database
$sql = "SELECT * FROM training_details";
$result = mysqli_query($conn, $sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>View Training Details</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>

  <style>
    .add-button {
      font-size: 20px;
      padding: 10px 15px;
      background-color: black;
      color: white;
      border: none;
      border-radius: 50%;
      cursor: pointer;
      position: fixed;
      bottom: 20px;
      right: 20px;
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2);
    }
    .add-button:hover {
      background-color: gray;
    }
  </style>
  <link rel="stylesheet" href="styles.css">
</head>
<body>
   <!-- Navigation Bar -->
   <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="index.php">Placement Portal</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="company_info.php">Company</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="training.php">Training</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="placed_students.php">Placed Students</a>
                    </li>
                </ul>
            </div>
            <div class="d-flex">
                <span class="navbar-text me-3">Welcome, <?= htmlspecialchars($_SESSION['username']); ?></span>
                <a href="main.php" class="btn btn-danger btn-sm">Logout</a>
            </div>
        </div>
    </nav>


  <div class="container mt-5">
    <h2 class="text-center mb-4">Training Details</h2>

    <!-- Check if there are any results to display -->
    <?php
    if (mysqli_num_rows($result) > 0) {
        echo '<table class="table table-striped">';
        echo '<thead>';
        echo '<tr>';
        echo '<th scope="col">#</th>';
        echo '<th scope="col">Organization Name</th>';
        echo '<th scope="col">Training Type</th>';
        echo '<th scope="col">Number of Days</th>';
        echo '<th scope="col">Trainer Details</th>';
        echo '<th scope="col">Syllabus</th>';
        echo '<th scope="col">Start Date</th>';
        echo '</tr>';
        echo '</thead>';
        echo '<tbody>';

        // Output data of each row
        while ($row = mysqli_fetch_assoc($result)) {
            echo '<tr>';
            echo '<td>' . $row['id'] . '</td>';
            echo '<td>' . $row['org_name'] . '</td>';
            echo '<td>' . ucfirst($row['training_type']) . '</td>';
            echo '<td>' . $row['num_days'] . '</td>';
            echo '<td>' . $row['trainer_details'] . '</td>';
            echo '<td>' . $row['syllabus'] . '</td>';
            echo '<td>' . $row['start_date'] . '</td>';
            echo '</tr>';
        }

        // Close the table
        echo '</tbody>';
        echo '</table>';
    } else {
        echo '<p>No training details available.</p>';
    }

    // Close the database connection
    mysqli_close($conn);
    ?>
  </div>

  <!-- Add Training Button -->
  <a href="add_training.php" class="add-button" title="Add New Training">+</a>
</body>
</html>
