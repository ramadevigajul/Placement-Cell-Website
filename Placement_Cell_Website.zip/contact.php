<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us - Placement Cell</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">

    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f9f9f9;
            color: #333;
        }
        header {
            background-color: #4CAF50;
            color: white;
            text-align: center;
            padding: 1rem;
        }
        main {
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
            background: white;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h1, h2 {
            color: black;
        }
        form {
            margin-top: 20px;
        }
        form label {
            font-weight: bold;
        }
        form input, form textarea {
            width: 100%;
            padding: 10px;
            margin: 8px 0;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        form button {
            background-color: black;
            color: white;
            border: none;
            padding: 10px 20px;
            font-size: 16px;
            cursor: pointer;
            border-radius: 4px;
        }
        form button:hover {
            background-color: gray;
        }
        footer {
            text-align: center;
            margin-top: 20px;
            font-size: 14px;
            color: #666;
        }
    </style>
    <script>
        // JavaScript to handle form submission
        function showSuccessMessage(event) {
            event.preventDefault(); // Prevent actual form submission
            alert("Your message has been sent successfully!");
            document.querySelector("form").reset(); // Reset the form fields
        }
    </script>
</head>
<body>
    <!-- Navigation Bar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="main.php">Placement Portal</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="company.php">Company</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="show_training.php">Training</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="students.php">Placed Students</a>
                    </li>
                    <li class="nav-item">
                    <a class="nav-link" href="about.php">About Us</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="contact.php">Contact Us</a>
                </li>
                </ul>
            </div>
            <div class="d-flex">
                
                <a href="login.php" class="btn btn-danger btn-sm">Login</a>
            </div>
        </div>
    </nav>
    <main>
        <p><strong>Address:</strong> Placement Cell Office, Shree Siddheshwar Women's College of Engineeering, , Bhawani Peth, Solapur, Maharashtra, 413002.</p>
        <p><strong>Phone:</strong> 0217 262 7227</p>
        <p><strong>Email:</strong> placementcell@sswcoe.edu</p>
        <p><strong>Working Hours:</strong> Monday to Saturday: 9:00 AM - 5:00 PM</p>
        
        <h2>Send Us a Message</h2>
        <form onsubmit="showSuccessMessage(event)">
            <label for="name">Name:</label>
            <input type="text" id="name" name="name" required>
            
            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required>
            
            <label for="message">Message:</label>
            <textarea id="message" name="message" rows="5" required></textarea>
            
            <button type="submit">Submit</button>
        </form>
    </main>
    <footer>
        Follow us on [Social Media Links]
    </footer>
</body>
</html>
