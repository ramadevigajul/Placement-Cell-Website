<?php
session_start();

// Redirect to login if the user is not logged in
if (!isset($_SESSION['username'])) {
    header('Location: login.php');
    exit();
}

include 'db.php'; // Include the database connection

// Check if the form was submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get the form data and sanitize them
    $student_name = htmlspecialchars($_POST['student_name']);
    $email = htmlspecialchars($_POST['email']);
    $mobile_no = htmlspecialchars($_POST['mobile_no']);
    $branch = htmlspecialchars($_POST['branch']);
    $class = htmlspecialchars($_POST['class']);
    $placed_company = htmlspecialchars($_POST['placed_company']);
    $package = htmlspecialchars($_POST['package']);

    // Insert data into the database
    $sql = "INSERT INTO placed_students (student_name, email, mobile_no, branch, class, placed_company, package) 
            VALUES ('$student_name', '$email', '$mobile_no', '$branch', '$class', '$placed_company', '$package')";

    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Student details added successfully!'); window.location.href = 'placed_students.php';</script>";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Add Student</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <!-- Navigation Bar -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container-fluid">
        <a class="navbar-brand" href="index.php">Placement Portal</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" href="company.php">Company</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="training.php">Training</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="placed_students.php">Placed Students</a>
                </li>
            </ul>
        </div>
        <div class="d-flex">
            <span class="navbar-text me-3">Welcome, <?= htmlspecialchars($_SESSION['username']); ?></span>
            <a href="main.php" class="btn btn-danger btn-sm">Logout</a>
        </div>
    </div>
  </nav>

    <!-- Main Content -->
    <div class="container mt-5" style="width: 80%; max-width:800px; margin: 0 auto; padding: 20px;">
        <h1>Add Student Details</h1>
        <p>Fill in the form below to add a new student to the database.</p>

        <!-- Student Form -->
        <form method="POST" action="add_placed_students.php">
            <div class="mb-3">
                <label for="student_name" class="form-label">Student Name</label>
                <input type="text" class="form-control" id="student_name" name="student_name" required>
            </div>
            <div class="mb-3">
                <label for="email" class="form-label">Email</label>
                <input type="email" class="form-control" id="email" name="email" required>
            </div>
            <div class="mb-3">
                <label for="mobile_no" class="form-label">Mobile Number</label>
                <input type="text" class="form-control" id="Academic_year" name="Ac" required>
            </div>
            <div class="mb-3">
                <label for="branch" class="form-label">Branch</label>
                <input type="text" class="form-control" id="branch" name="branch" required>
            </div>
            <div class="mb-3">
                <label for="class" class="form-label">Class</label>
                <input type="text" class="form-control" id="class" name="class" required>
            </div>
            <div class="mb-3">
                <label for="placed_company" class="form-label">Placed Company</label>
                <input type="text" class="form-control" id="placed_company" name="placed_company" required>
            </div>
            <div class="mb-3">
                <label for="package" class="form-label">Package</label>
                <input type="text" class="form-control" id="package" name="package" required>
            </div>

            <button type="submit" class="btn btn-primary" style="background-color:black;">Add Student</button>
        </form>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
