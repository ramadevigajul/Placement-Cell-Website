<?php
session_start();

// Redirect to login if the user is not logged in
if (!isset($_SESSION['username'])) {
    header('Location: login.php');
    exit();
}

include 'db.php'; // Include the database connection

// Check if the form was submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get the form data and sanitize them
    $name = htmlspecialchars($_POST['name']);
    $founder = htmlspecialchars($_POST['founder']);
    $ceo = htmlspecialchars($_POST['ceo']);
    $chairman = htmlspecialchars($_POST['chairman']);
    $founded_date = htmlspecialchars($_POST['founded_date']);
    $headquarters = htmlspecialchars($_POST['headquarters']);
    $official_link = htmlspecialchars($_POST['official_link']);

    // Insert data into the database
    $sql = "INSERT INTO companies (name, founder, ceo, chairman, founded_date, headquarters, official_link) 
            VALUES ('$name', '$founder', '$ceo', '$chairman', '$founded_date', '$headquarters', '$official_link')";

    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Company details added successfully!'); window.location.href = 'company_info.php';</script>";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Add Company</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    
   <!-- Navigation Bar -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container-fluid">
        <a class="navbar-brand" href="index.php">Placement Portal</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" href="company.php">Company</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="training.php">Training</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="placed_students.php">Placed Students</a>
                </li>
            </ul>
        </div>
        <div class="d-flex">
            <span class="navbar-text me-3">Welcome, <?= htmlspecialchars($_SESSION['username']); ?></span>
            <a href="main.php" class="btn btn-danger btn-sm">Logout</a>
        </div>
    </div>
  </nav>
    <!-- Main Content -->
    <div class="container mt-5" style="width: 80%; max-width:800px; margin: 0 auto; padding: 20px;">
        <h1>Add Company Details</h1>
        <p>Fill in the form below to add a new company to the database.</p>

        <!-- Company Form -->
        <form method="POST" action="add_company.php">
            <div class="mb-3">
                <label for="name" class="form-label">Company Name</label>
                <input type="text" class="form-control" id="name" name="name" required>
            </div>
            <div class="mb-3">
                <label for="founder" class="form-label">Founder</label>
                <input type="text" class="form-control" id="founder" name="founder" required>
            </div>
            <div class="mb-3">
                <label for="ceo" class="form-label">CEO</label>
                <input type="text" class="form-control" id="ceo" name="ceo" required>
            </div>
            <div class="mb-3">
                <label for="chairman" class="form-label">Chairman</label>
                <input type="text" class="form-control" id="chairman" name="chairman" required>
            </div>
            <div class="mb-3">
                <label for="founded_date" class="form-label">Founded Date</label>
                <input type="date" class="form-control" id="founded_date" name="founded_date" required>
            </div>
            <div class="mb-3">
                <label for="headquarters" class="form-label">Headquarters</label>
                <input type="text" class="form-control" id="headquarters" name="headquarters" required>
            </div>
            <div class="mb-3">
                <label for="official_link" class="form-label">Official Website Link</label>
                <input type="url" class="form-control" id="official_link" name="official_link" required>
            </div>

            <button type="submit" class="btn btn-primary" style="background-color:black;">Add Company</button>
        </form>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
