<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <title>About Us - Placement Cell</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f9f9f9;
            color: #333;
        }
        header {
            background-color: #4CAF50;
            color: white;
            text-align: center;
            padding: 1rem;
        }
        main {
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
            background: white;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h1, h2 {
            color: black;
        }
        ul {
            list-style-type: square;
            padding-left: 20px;
        }
        blockquote {
            font-style: italic;
            color: #555;
            border-left: 4px solid black;
            margin: 10px 0;
            padding-left: 10px;
        }
        footer {
            text-align: center;
            margin-top: 20px;
            font-size: 14px;
            color: #666;
        }
    </style>
</head>
<body>
   <!-- Navigation Bar -->
   <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="main.php">Placement Portal</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="company.php">Company</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="show_training.php">Training</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="students.php">Placed Students</a>
                    </li>
                    <li class="nav-item">
                    <a class="nav-link" href="about.php">About Us</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="contact.php">Contact Us</a>
                </li>
                </ul>
            </div>
            <div class="d-flex">
                
                <a href="login.php" class="btn btn-danger btn-sm">Login</a>
            </div>
        </div>
    </nav>
    <main>
        <p>The Placement Cell at <strong>Shree Siddheshwar Women's College of Engeering</strong> is dedicated to bridging the gap between students and placement team. We provide a platform for students to know about our Recruitment partners,Training details and Students placed in different companies.</p>
        
        
        <h2>Our Team</h2>
        <ul>
            <li><strong>Incharge TPO Coordinator:</strong> Prof. A. P. Gajare</li>
            <li><strong>TPO Computer Science & Engineering Department:</strong> Prof. Y.R. Kalshetty</li>
            <li><strong>TPO Electronics & Telecommunication Engineering Department:</strong>Prof. E.R. Chandane</li>
            <li><strong>TPO Electrical Engineering Department:</strong> Prof. D.S.Waghmode</li>
            <li><strong>TPO Computer Science & Engineering(AI & DS) Department:</strong>Prof. V.V.Shirashyad</li>
            <li><strong>TPO Electrical Engineering Department:</strong> Prof.P.H.Nare</li>
        </ul>
        
        <blockquote>"Your Career, Our Commitment."</blockquote>
    </main>
    <footer>
        © 2024 Placement Cell. All Rights Reserved.
    </footer>
</body>
</html>
