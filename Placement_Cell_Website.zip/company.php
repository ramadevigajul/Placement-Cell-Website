<?php
// Include the database connection
include 'db.php'; 

// Fetch the company data from the database
$sql = "SELECT * FROM companies";
$result = $conn->query($sql);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Company Details</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <style>
        body {
    background-color: #f9f9f9;
    font-family: 'Arial', sans-serif;
    color: #333;
}

.container {
    background: white;
    border-radius: 8px;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    padding: 20px;
}

h2 {
    color: black;
    margin-bottom: 20px;
}

.table {
    background-color: #ffffff;
    border-radius: 8px;
    overflow: hidden;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}

.table thead {
    background-color: #007BFF;
    color: white;
}

.table tbody tr:hover {
    background-color: #f1f1f1;
}
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="main.php">Placement Portal</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="company.php">Company</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="show_training.php">Training</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="show_placed_students.php">Placed Students</a>
                    </li>
                     <li class="nav-item">
                    <a class="nav-link" href="about.php">About Us</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="contact.php">Contact Us</a>
                </li>
                </ul>
            </div>
            <div class="d-flex">
                
                <a href="main.php" class="btn btn-danger btn-sm">Login</a>
            </div>
        </div>
    </nav>

<div class="container mt-5">
    <h2 class="text-center">Company Details</h2>
    
    <!-- Company Table -->
    <table class="table table-striped">
        <thead>
            <tr>
                <th>ID</th>
                <th>Company Name</th>
                <th>Founder</th>
                <th>CEO</th>
                <th>Chairman</th>
                <th>Founded Date</th>
                <th>Headquarters</th>
                <th>Official Link</th>
            </tr>
        </thead>
        <tbody>
            <?php
            // Check if there are results from the database query
            if ($result->num_rows > 0) {
                // Output data of each row
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>
                            <td>" . $row['id'] . "</td>
                            <td>" . $row['name'] . "</td>
                            <td>" . $row['founder'] . "</td>
                            <td>" . $row['ceo'] . "</td>
                            <td>" . $row['chairman'] . "</td>
                            <td>" . date('d-m-Y', strtotime($row['founded_date'])) . "</td>
                            <td>" . $row['headquarters'] . "</td>
                            <td><a href='" . $row['official_link'] . "' target='_blank'>Official Site</a></td>
                          </tr>";
                }
            } else {
                echo "<tr><td colspan='8'>No company details found.</td></tr>";
            }
            ?>
        </tbody>
    </table>
</div>

</body>
</html>
